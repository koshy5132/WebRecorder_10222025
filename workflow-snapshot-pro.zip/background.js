// Workflow Snapshot Pro - Chrome Web Store Compliant Background Service
(function() {
  'use strict';
  
  let sessionId = null;
  let snapshots = [];
  let isRecording = false;
  let currentTabId = null;

  console.log("🔧 WORKFLOW SNAPSHOT PRO: Chrome Web Store compliant service worker initialized");

  function getSessionId() {
    if (!sessionId) {
      sessionId = "session-" + Date.now();
      console.log("🆔 PRO: Generated session ID:", sessionId);
    }
    return sessionId;
  }

  function stopAllProcesses() {
    try {
      console.log("🛑 PRO: Stopping all processes");
      isRecording = false;
      currentTabId = null;
      
      chrome.storage.local.set({ running: false });
    } catch (error) {
      console.error("❌ PRO: Error in stopAllProcesses", error);
    }
  }

  function captureScreenshot(msg) {
    if (!isRecording) {
      console.log("❌ PRO: Not recording, ignoring capture");
      return;
    }

    try {
      // Use activeTab permission - only capture the current active tab
      chrome.tabs.captureVisibleTab(null, {format: "png"}, (dataUrl) => {
        if (chrome.runtime.lastError) {
          console.error("❌ PRO: Capture error:", chrome.runtime.lastError.message);
          return;
        }

        if (!dataUrl || !isRecording) {
          console.warn("❌ PRO: No data URL or recording stopped");
          return;
        }

        const sid = getSessionId();
        const timestamp = Date.now();
        const type = msg.isInitial ? "initial" : (msg.isClick ? "click" : "url");
        const filename = sid + "/" + type + "-snapshot-" + timestamp + ".png";
        
        // Download screenshot
        chrome.downloads.download({
          url: dataUrl,
          filename: filename,
          saveAs: false
        });

        const snapshotData = {
          filename: filename,
          dataUrl: dataUrl,
          time: new Date().toLocaleTimeString(),
          date: new Date().toLocaleDateString(),
          timestamp: timestamp,
          x: msg.x || 0,
          y: msg.y || 0,
          type: type,
          url: msg.url || "Current tab",
          clickNumber: msg.clickNumber || null
        };

        snapshots.push(snapshotData);
        chrome.storage.local.set({snapshots: snapshots});
        
        console.log("✅ PRO: Captured", type, "snapshot #" + (msg.clickNumber || ""));
      });
    } catch (error) {
      console.error("❌ PRO: Capture screenshot error", error);
    }
  }

  function generateProfessionalReport() {
    try {
      if (snapshots.length === 0) {
        console.log("❌ PRO: No snapshots to generate report");
        chrome.storage.local.set({ running: false, snapshots: [] });
        return;
      }

      chrome.storage.local.get(["folderPrefix"], (data) => {
        try {
          const prefix = data.folderPrefix || "workflow";
          const sid = getSessionId();
          const folder = prefix + "-" + sid;

          // Professional HTML report
          let html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Workflow Documentation - Professional Report</title>';
          html += '<style>';
          html += '* { margin: 0; padding: 0; box-sizing: border-box; }';
          html += 'body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; color: #333; background: #f8fafc; padding: 0; }';
          html += '.container { max-width: 1200px; margin: 0 auto; padding: 20px; }';
          html += '.header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 0; margin-bottom: 40px; border-radius: 0 0 20px 20px; }';
          html += '.header-content { max-width: 1200px; margin: 0 auto; padding: 0 20px; text-align: center; }';
          html += '.header h1 { font-size: 2.5em; margin-bottom: 10px; font-weight: 300; }';
          html += '.header p { font-size: 1.1em; opacity: 0.9; }';
          html += '.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }';
          html += '.stat-card { background: white; padding: 25px; border-radius: 12px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; }';
          html += '.stat-number { font-size: 2em; font-weight: bold; color: #667eea; margin-bottom: 5px; }';
          html += '.stat-label { color: #64748b; font-size: 0.9em; text-transform: uppercase; letter-spacing: 0.5px; }';
          html += '.snapshot-card { background: white; margin-bottom: 30px; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; transition: transform 0.2s ease, box-shadow 0.2s ease; }';
          html += '.snapshot-card:hover { transform: translateY(-2px); box-shadow: 0 8px 15px rgba(0,0,0,0.1); }';
          html += '.card-header { background: #f8fafc; padding: 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }';
          html += '.step-info { padding: 20px; }';
          html += '.step-meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px; }';
          html += '.meta-item { background: #f1f5f9; padding: 12px; border-radius: 8px; }';
          html += '.meta-label { font-size: 0.85em; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 5px; }';
          html += '.meta-value { font-weight: 500; color: #334155; }';
          html += '.snapshot-image { width: 100%; border: 1px solid #e2e8f0; border-radius: 8px; margin: 15px 0; }';
          html += '.badge { display: inline-flex; align-items: center; padding: 6px 12px; border-radius: 20px; font-size: 0.8em; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }';
          html += '.badge-initial { background: #10b981; color: white; }';
          html += '.badge-click { background: #ef4444; color: white; }';
          html += '.badge-url { background: #3b82f6; color: white; }';
          html += '.click-number { background: rgba(255,255,255,0.2); color: white; padding: 2px 6px; border-radius: 50%; margin-left: 5px; font-size: 0.7em; }';
          html += '.delete-btn { background: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85em; font-weight: 500; transition: background 0.2s ease; }';
          html += '.delete-btn:hover { background: #dc2626; }';
          html += '.footer { text-align: center; padding: 40px 20px; color: #64748b; font-size: 0.9em; border-top: 1px solid #e2e8f0; margin-top: 40px; }';
          html += '</style>';
          html += '<script>';
          html += 'function deleteSnapshot(index) {';
          html += '  if (confirm("Delete this snapshot? This will remove it from the report.")) {';
          html += '    const card = document.getElementById("snapshot-" + index);';
          html += '    if (card) {';
          html += '      card.style.opacity = "0.5";';
          html += '      card.style.transition = "opacity 0.3s ease";';
          html += '      setTimeout(() => {';
          html += '        card.remove();';
          html += '        updateStepNumbers();';
          html += '        updateStats();';
          html += '      }, 300);';
          html += '    }';
          html += '  }';
          html += '}';
          html += 'function updateStepNumbers() {';
          html += '  const cards = document.querySelectorAll(".snapshot-card");';
          html += '  cards.forEach((card, newIndex) => {';
          html += '    const title = card.querySelector("h3");';
          html += '    if (title) {';
          html += '      title.textContent = title.textContent.replace(/Step \\d+/, "Step " + (newIndex + 1));';
          html += '    }';
          html += '    card.id = "snapshot-" + newIndex;';
          html += '    const deleteBtn = card.querySelector(".delete-btn");';
          html += '    if (deleteBtn) {';
          html += '      deleteBtn.setAttribute("onclick", "deleteSnapshot(" + newIndex + ")");';
          html += '    }';
          html += '  });';
          html += '}';
          html += 'function updateStats() {';
          html += '  const totalCards = document.querySelectorAll(".snapshot-card").length;';
          html += '  document.getElementById("total-steps").textContent = totalCards;';
          html += '  document.getElementById("click-steps").textContent = document.querySelectorAll(".badge-click").length;';
          html += '  document.getElementById("url-steps").textContent = document.querySelectorAll(".badge-url").length;';
          html += '}';
          html += '</script>';
          html += '</head><body>';
          html += '<div class="header"><div class="header-content">';
          html += '<h1>Workflow Documentation</h1>';
          html += '<p>Professional workflow analysis generated ' + new Date().toLocaleString() + '</p>';
          html += '<p>Session: ' + folder + '</p>';
          html += '</div></div>';
          html += '<div class="container">';
          html += '<div class="stats">';
          html += '<div class="stat-card"><div class="stat-number" id="total-steps">' + snapshots.length + '</div><div class="stat-label">Total Steps</div></div>';
          html += '<div class="stat-card"><div class="stat-number" id="click-steps">' + snapshots.filter(s => s.type === 'click').length + '</div><div class="stat-label">User Clicks</div></div>';
          html += '<div class="stat-card"><div class="stat-number" id="url-steps">' + snapshots.filter(s => s.type === 'url').length + '</div><div class="stat-label">URL Visits</div></div>';
          html += '<div class="stat-card"><div class="stat-number">' + (snapshots.filter(s => s.type === 'initial').length) + '</div><div class="stat-label">Initial States</div></div>';
          html += '</div>';

          snapshots.forEach(function(snapshot, index) {
            const badgeClass = snapshot.type === 'initial' ? 'badge-initial' : 
                             snapshot.type === 'click' ? 'badge-click' : 'badge-url';
            const badgeText = snapshot.type === 'initial' ? 'Initial State' : 
                            snapshot.type === 'click' ? 'User Interaction' : 'URL Visit';
            
            const clickBadge = snapshot.clickNumber ? '<span class="click-number">' + snapshot.clickNumber + '</span>' : '';
            
            html += '<div class="snapshot-card" id="snapshot-' + index + '">';
            html += '<div class="card-header">';
            html += '<div><h3>Step ' + (index + 1) + '</h3><span class="badge ' + badgeClass + '">' + badgeText + clickBadge + '</span></div>';
            html += '<button class="delete-btn" onclick="deleteSnapshot(' + index + ')">Delete Step</button>';
            html += '</div>';
            html += '<div class="step-info">';
            html += '<div class="step-meta">';
            html += '<div class="meta-item"><div class="meta-label">Time</div><div class="meta-value">' + snapshot.time + '</div></div>';
            html += '<div class="meta-item"><div class="meta-label">Date</div><div class="meta-value">' + snapshot.date + '</div></div>';
            if (snapshot.type === 'click') {
              html += '<div class="meta-item"><div class="meta-label">Click Position</div><div class="meta-value">(' + snapshot.x + ', ' + snapshot.y + ')</div></div>';
            }
            if (snapshot.url && snapshot.url !== "Current tab") {
              html += '<div class="meta-item"><div class="meta-label">URL</div><div class="meta-value" style="word-break: break-all;">' + snapshot.url + '</div></div>';
            }
            html += '</div>';
            html += '<img class="snapshot-image" src="' + snapshot.dataUrl + '" alt="Step ' + (index + 1) + ' screenshot">';
            html += '<div class="meta-item"><div class="meta-label">Filename</div><div class="meta-value">' + snapshot.filename + '</div></div>';
            html += '</div>';
            html += '</div>';
          });
          
          html += '<div class="footer">';
          html += '<p>Generated by Workflow Snapshot Pro - Professional Workflow Documentation Tool</p>';
          html += '<p>All screenshots and interactions captured automatically</p>';
          html += '</div>';
          html += '</div></body></html>';
          
          const dataUrl = "data:text/html;charset=utf-8," + encodeURIComponent(html);
          const filename = folder + "/workflow-documentation.html";
          
          chrome.downloads.download({
            url: dataUrl,
            filename: filename,
            saveAs: false
          }, () => {
            console.log("✅ PRO: Professional report generated");
            snapshots = [];
            sessionId = null;
            chrome.storage.local.set({ running: false, snapshots: [] });
          });
        } catch (error) {
          console.error("❌ PRO: HTML generation error", error);
        }
      });
    } catch (error) {
      console.error("❌ PRO: Final report error", error);
    }
  }

  // Professional message handler
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      if (msg.action === "captureScreenshot") {
        captureScreenshot(msg);
        sendResponse({success: true});
      }
      else if (msg.action === "stopRecording") {
        stopAllProcesses();
        generateProfessionalReport();
        sendResponse({success: true});
      }
      else if (msg.action === "startRecording") {
        // Get the current active tab when recording starts
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
          if (tabs && tabs[0]) {
            currentTabId = tabs[0].id;
            isRecording = true;
            sessionId = "session-" + Date.now();
            snapshots = [];
            chrome.storage.local.set({ running: true, snapshots: [] });
            sendResponse({success: true, sessionId: sessionId});
          } else {
            sendResponse({success: false, error: "No active tab found"});
          }
        });
        return true; // Keep message channel open for async response
      }
      else if (msg.action === "processUrls") {
        // URL processing removed for Chrome Web Store compliance
        // Users can manually navigate and click instead
        sendResponse({success: false, error: "URL processing not available in Chrome Web Store version"});
      }
    } catch (error) {
      console.error("❌ PRO: Message handler error", error);
      sendResponse({success: false, error: error.message});
    }
    return true;
  });

  // Initialize state
  chrome.storage.local.get(["running", "snapshots"], (data) => {
    isRecording = data.running || false;
    snapshots = data.snapshots || [];
  });

})();