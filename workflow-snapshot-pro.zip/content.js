// Workflow Snapshot Pro - Chrome Web Store Compliant
(function() {
  'use strict';
  
  let running = false;
  let lastCapture = 0;
  let clickCounter = 0;
  let highlightStyleAdded = false;

  // Professional highlight system
  function createProfessionalHighlight(e, clickNumber) {
    try {
      // Create container for both elements
      const container = document.createElement("div");
      container.className = 'workflow-highlight-container';
      
      // Create glowing ring with professional styling
      const ring = document.createElement("div");
      ring.className = 'workflow-glow-ring';
      
      // Create professional numbered badge
      const badge = document.createElement("div");
      badge.className = 'workflow-click-badge';
      badge.textContent = clickNumber;
      
      // Professional positioning and sizing
      const ringSize = 70;
      const badgeSize = 32;
      const clickX = e.clientX;
      const clickY = e.clientY;
      
      // Position ring (centered on click)
      Object.assign(ring.style, {
        position: "fixed",
        left: (clickX - ringSize/2) + "px",
        top: (clickY - ringSize/2) + "px",
        width: ringSize + "px",
        height: ringSize + "px",
        border: "4px solid #FF6B35",
        borderRadius: "50%",
        zIndex: "2147483647", // Maximum z-index
        pointerEvents: "none",
        animation: "workflow-glow-pulse 2s ease-out forwards",
        boxSizing: "border-box"
      });
      
      // Position badge (centered on click)
      Object.assign(badge.style, {
        position: "fixed",
        left: (clickX - badgeSize/2) + "px",
        top: (clickY - badgeSize/2) + "px",
        width: badgeSize + "px",
        height: badgeSize + "px",
        background: "linear-gradient(135deg, #FF6B35, #FF8E53)",
        color: "white",
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "14px",
        fontWeight: "bold",
        fontFamily: "Arial, sans-serif",
        zIndex: "2147483647", // Maximum z-index
        pointerEvents: "none",
        animation: "workflow-badge-pop 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards",
        boxShadow: "0 4px 15px rgba(255, 107, 53, 0.4)",
        textShadow: "0 1px 2px rgba(0,0,0,0.3)",
        boxSizing: "border-box"
      });

      // Add to page directly (not in container)
      if (document.body) {
        document.body.appendChild(ring);
        document.body.appendChild(badge);
        
        // Professional cleanup with fade out
        setTimeout(() => {
          try {
            // Add fade out animation
            ring.style.opacity = "0";
            ring.style.transition = "opacity 0.3s ease";
            badge.style.opacity = "0";
            badge.style.transition = "opacity 0.3s ease";
            
            // Remove after fade
            setTimeout(() => {
              if (ring.parentNode) ring.remove();
              if (badge.parentNode) badge.remove();
            }, 300);
          } catch (error) {
            // Fallback: immediate removal
            try {
              if (ring.parentNode) ring.remove();
              if (badge.parentNode) badge.remove();
            } catch (e) {}
          }
        }, 1700); // Show for 1.7 seconds total
      }
      
      return { ring, badge };
    } catch (error) {
      console.warn('Workflow Snapshot Pro: Error creating highlight', error);
      return null;
    }
  }

  // Enhanced click handler with better timing
  function handleClick(e) {
    if (!running) return;
    
    const now = Date.now();
    if (now - lastCapture < 300) return; // Reduced cooldown for better UX
    lastCapture = now;

    try {
      clickCounter++;
      
      // Create professional highlight immediately
      createProfessionalHighlight(e, clickCounter);
      
      // Capture screenshot with slight delay to ensure highlight is visible
      setTimeout(() => {
        try {
          chrome.runtime.sendMessage({
            action: "captureScreenshot",
            x: e.clientX,
            y: e.clientY,
            isClick: true,
            url: window.location.href,
            clickNumber: clickCounter,
            timestamp: Date.now()
          }, (response) => {
            if (chrome.runtime.lastError) {
              console.debug('Workflow Snapshot Pro: Message port closed');
            }
          });
        } catch (error) {
          console.warn('Workflow Snapshot Pro: Screenshot message error', error);
        }
      }, 50); // Small delay to ensure highlight is rendered
      
    } catch (error) {
      console.warn("Workflow Snapshot Pro: Click handler error", error);
    }
  }

  // Add professional styles once
  function addProfessionalStyles() {
    if (highlightStyleAdded) return;
    
    try {
      const professionalStyles = document.createElement('style');
      professionalStyles.id = 'workflow-pro-styles';
      professionalStyles.textContent = [
        '/* Professional Animation System */',
        '@keyframes workflow-glow-pulse {',
        '  0% { transform: scale(0.3); opacity: 0.8; box-shadow: 0 0 0 0 rgba(255, 107, 53, 0.7); }',
        '  50% { transform: scale(1.1); opacity: 1; box-shadow: 0 0 0 15px rgba(255, 107, 53, 0); }',
        '  80% { transform: scale(1); opacity: 0.9; box-shadow: 0 0 0 25px rgba(255, 107, 53, 0); }',
        '  100% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 30px rgba(255, 107, 53, 0); }',
        '}',
        '',
        '@keyframes workflow-badge-pop {',
        '  0% { transform: scale(0) rotate(-180deg); opacity: 0; }',
        '  60% { transform: scale(1.1) rotate(5deg); opacity: 1; }',
        '  80% { transform: scale(0.95) rotate(-2deg); opacity: 1; }',
        '  100% { transform: scale(1) rotate(0deg); opacity: 1; }',
        '}',
        '',
        '/* High contrast for all backgrounds */',
        '.workflow-glow-ring {',
        '  border: 4px solid #FF6B35 !important;',
        '  filter: drop-shadow(0 0 8px rgba(255, 107, 53, 0.8));',
        '}',
        '',
        '.workflow-click-badge {',
        '  background: linear-gradient(135deg, #FF6B35, #FF8E53) !important;',
        '  border: 2px solid white !important;',
        '  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;',
        '  font-weight: 700 !important;',
        '  text-shadow: 0 1px 3px rgba(0,0,0,0.5) !important;',
        '  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));',
        '}'
      ].join('\n');
      
      document.head.appendChild(professionalStyles);
      highlightStyleAdded = true;
      console.log('Workflow Snapshot Pro: Professional styles loaded');
    } catch (error) {
      console.warn('Workflow Snapshot Pro: Style injection error', error);
    }
  }

  // Enhanced storage change listener
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local" && changes.running) {
      const newRunning = changes.running.newValue;
      
      if (newRunning && !running) {
        // Starting recording
        running = true;
        clickCounter = 0;
        document.addEventListener("click", handleClick, true);
        addProfessionalStyles();
        
        console.log('Workflow Snapshot Pro: Recording started');
        
        // Send initial snapshot after a brief delay
        setTimeout(() => {
          try {
            chrome.runtime.sendMessage({
              action: "captureScreenshot",
              x: 0,
              y: 0,
              isInitial: true,
              url: window.location.href,
              timestamp: Date.now()
            });
          } catch (error) {
            console.warn('Workflow Snapshot Pro: Initial capture error', error);
          }
        }, 800);
        
      } else if (!newRunning && running) {
        // Stopping recording
        running = false;
        document.removeEventListener("click", handleClick, true);
        console.log('Workflow Snapshot Pro: Recording stopped');
      }
    }
  });

  // Professional initialization
  function initialize() {
    try {
      chrome.storage.local.get(["running"], (data) => {
        running = data.running || false;
        if (running) {
          document.addEventListener("click", handleClick, true);
          addProfessionalStyles();
          console.log('Workflow Snapshot Pro: Re-initialized in recording state');
        }
      });
    } catch (error) {
      console.warn('Workflow Snapshot Pro: Initialization error', error);
    }
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }

  // Re-initialize if page changes (SPA support)
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(initialize, 100);
    }
  }).observe(document, { subtree: true, childList: true });

})();