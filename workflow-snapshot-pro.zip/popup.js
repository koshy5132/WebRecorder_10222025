// Workflow Snapshot Pro - Chrome Web Store Compliant Popup
(function() {
  'use strict';
  
  // DOM Elements
  const folderInput = document.getElementById("folderPrefix");
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");
  const statusDiv = document.getElementById("status");

  let isRecording = false;

  // Professional status management
  function updateStatus(recording) {
    isRecording = recording;
    if (isRecording) {
      statusDiv.textContent = "● Recording workflow... Click anywhere to capture";
      statusDiv.className = "status recording";
      startBtn.disabled = true;
      stopBtn.disabled = false;
    } else {
      statusDiv.textContent = "Ready to start workflow recording";
      statusDiv.className = "status idle";
      startBtn.disabled = false;
      stopBtn.disabled = true;
    }
  }

  function showNotification(message, type = 'info') {
    console.log("Workflow Snapshot Pro:", message);
    // Could be enhanced with toast notifications
  }

  // Event Listeners with professional error handling
  startBtn.addEventListener("click", () => {
    const prefix = folderInput.value.trim() || "workflow";
    chrome.runtime.sendMessage({ action: "startRecording" }, (response) => {
      if (chrome.runtime.lastError) {
        showNotification("Error starting recording: " + chrome.runtime.lastError.message, "error");
      } else if (response && response.success) {
        chrome.storage.local.set({ folderPrefix: prefix });
        updateStatus(true);
        showNotification("Workflow recording started - click anywhere to capture", "success");
      } else {
        showNotification("Failed to start recording: " + (response.error || "Unknown error"), "error");
      }
    });
  });

  stopBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "stopRecording" }, (response) => {
      if (chrome.runtime.lastError) {
        showNotification("Error stopping recording", "error");
      } else {
        showNotification("Generating professional workflow report...", "success");
        updateStatus(false);
      }
    });
  });

  // Professional initialization
  function initialize() {
    // Load current recording state
    chrome.storage.local.get(["running"], (data) => {
      updateStatus(data.running || false);
    });
    
    // Set focus to folder input for better UX
    folderInput.focus();
  }

  // Initialize when ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }

  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local" && changes.running) {
      updateStatus(changes.running.newValue);
    }
  });

})();