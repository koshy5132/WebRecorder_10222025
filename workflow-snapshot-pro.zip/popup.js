// Workflow Snapshot Pro - Professional Popup
(function() {
  'use strict';
  
  // DOM Elements
  const folderInput = document.getElementById("folderPrefix");
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");
  const processUrlsBtn = document.getElementById("processUrlsBtn");
  const urlsInput = document.getElementById("urlsInput");
  const addListBtn = document.getElementById("addListBtn");
  const urlList = document.getElementById("urlList");
  const statusDiv = document.getElementById("status");

  let urls = [];
  let isRecording = false;

  // Professional status management
  function updateStatus(recording) {
    isRecording = recording;
    if (isRecording) {
      statusDiv.textContent = "● Recording workflow... Click anywhere to capture";
      statusDiv.className = "status recording";
      startBtn.disabled = true;
      stopBtn.disabled = false;
      processUrlsBtn.disabled = urls.length === 0;
    } else {
      statusDiv.textContent = "Ready to start workflow recording";
      statusDiv.className = "status idle";
      startBtn.disabled = false;
      stopBtn.disabled = true;
      processUrlsBtn.disabled = true;
    }
  }

  function showNotification(message, type = 'info') {
    console.log("Workflow Snapshot Pro:", message);
    // Could be enhanced with toast notifications
  }

  // Professional URL list rendering
  function renderUrlList() {
    urlList.innerHTML = "";
    if (urls.length === 0) {
      urlList.innerHTML = '<div class="empty-state">No URLs added yet</div>';
      return;
    }
    
    urls.forEach((url) => {
      const div = document.createElement("div");
      div.className = "url-item";
      
      const span = document.createElement("div");
      span.className = "url-text";
      span.textContent = url;
      span.title = url;
      
      const btn = document.createElement("button");
      btn.className = "delete-btn";
      btn.textContent = "Remove";
      btn.addEventListener("click", () => {
        urls = urls.filter(u => u !== url);
        chrome.storage.local.set({urls});
        renderUrlList();
        updateStatus(isRecording);
        showNotification("URL removed from list");
      });
      
      div.appendChild(span);
      div.appendChild(btn);
      urlList.appendChild(div);
    });
  }

  function loadUrls() {
    chrome.storage.local.get(["urls", "running"], (data) => {
      urls = data.urls || [];
      renderUrlList();
      updateStatus(data.running || false);
    });
  }

  function isValidUrl(string) {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  }

  // Professional URL validation and processing
  function validateAndProcessUrls(text) {
    const lines = text.split(/\n+/)
      .map(s => s.trim())
      .filter(Boolean)
      .filter(line => !line.startsWith('#') && line.length > 0);
    
    const valid = lines.filter(isValidUrl);
    const invalid = lines.filter(line => !isValidUrl(line));
    
    if (invalid.length > 0) {
      showNotification("Skipped " + invalid.length + " invalid URLs", "warning");
    }
    
    return valid;
  }

  // Event Listeners with professional error handling
  addListBtn.addEventListener("click", () => {
    const text = urlsInput.value.trim();
    if (!text) {
      showNotification("Please enter URLs first", "warning");
      return;
    }
    
    const validUrls = validateAndProcessUrls(text);
    if (validUrls.length === 0) {
      showNotification("No valid URLs found. Include http:// or https://", "error");
      return;
    }
    
    urls = Array.from(new Set([...urls, ...validUrls]));
    chrome.storage.local.set({urls}, () => {
      urlsInput.value = "";
      renderUrlList();
      updateStatus(isRecording);
      showNotification(validUrls.length + " URLs added to processing list");
    });
  });

  processUrlsBtn.addEventListener("click", () => {
    if (urls.length === 0) {
      showNotification("No URLs to process", "warning");
      return;
    }
    
    chrome.runtime.sendMessage({ action: "processUrls", urls }, (response) => {
      if (chrome.runtime.lastError) {
        showNotification("Error starting URL processing", "error");
      } else if (response && !response.success) {
        showNotification(response.error || "Failed to process URLs", "error");
      } else {
        showNotification("Processing " + urls.length + " URLs automatically...");
      }
    });
  });

  startBtn.addEventListener("click", () => {
    const prefix = folderInput.value.trim() || "workflow";
    chrome.runtime.sendMessage({ action: "startRecording" }, (response) => {
      if (chrome.runtime.lastError) {
        showNotification("Error starting recording: " + chrome.runtime.lastError.message, "error");
      } else if (response && response.success) {
        chrome.storage.local.set({ folderPrefix: prefix });
        updateStatus(true);
        showNotification("Workflow recording started - click anywhere to capture", "success");
      } else {
        showNotification("Failed to start recording", "error");
      }
    });
  });

  stopBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "stopRecording" }, (response) => {
      if (chrome.runtime.lastError) {
        showNotification("Error stopping recording", "error");
      } else {
        showNotification("Generating professional workflow report...", "success");
        updateStatus(false);
      }
    });
  });

  // Professional initialization
  function initialize() {
    loadUrls();
    
    // Set focus to folder input for better UX
    folderInput.focus();
  }

  // Initialize when ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }

  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local") {
      if (changes.running) {
        updateStatus(changes.running.newValue);
      }
      if (changes.urls) {
        loadUrls();
      }
    }
  });

})();